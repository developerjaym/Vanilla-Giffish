export class StorageService {

    async save(data) {
        throw new Error("not implemented")
    }
    async read() {
        throw new Error("not implemented")
    }
}